﻿using System;

namespace classWork1
{
    class Program
    {
        static void Main(string[] args)
        {
            string heroName = "Somou";
            double Herohight = 165.5;
            int heroAge = 20;
            string heroSuperPower = "Hope";

            string villainName = "Editor";
            double villainhight = 155.5;
            int villainAge = 40;
            string villainSuperPower = "internetConnection";

            int ageDifference = heroAge - villainAge;


            Console.WriteLine("I have an hero called " + heroName + " the hight of my amazing hero is  " + Herohight + " .The hero is" + heroAge + " years old , also his power is  " + heroSuperPower);
            Console.WriteLine("My villain is called " + villainName + " the hight of my villain is  " + Herohight + " .The Editor is " + villainAge + " years old , also his power is  " + villainSuperPower);
            // Bounce part 
            double Newherohight = Herohight + 5;
             villainSuperPower = "None";
            Console.WriteLine(heroName);
            Console.WriteLine(heroAge);
            Console.WriteLine(heroSuperPower);
            Console.WriteLine(villainName);
            Console.WriteLine(villainhight);
            Console.WriteLine(ageDifference);
            Console.WriteLine(Newherohight);
            Console.WriteLine(villainSuperPower);
     
        }
    }
}



